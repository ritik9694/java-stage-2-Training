package com.cognizant.gatewayserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayserverApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.cognizant.cards.exception;

public class CardAlreadyExistsException extends RuntimeException {

	public CardAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	

}

package com.cognizant.cards.service;

import com.cognizant.cards.dto.CardsDto;

public interface CardsService {
	
	void createCard(String mobileNumber);
	
	CardsDto fetchCard(String mobileNumber);
	
	boolean updateDetails(CardsDto cardsDto);
	
	boolean deleteDetails(String mobileNumber);

}
